import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class test {
    @Id
    @GeneratedValue

    @Column(name = "nazwa")
    private String nazwa;
    @Column(name = "typ")
    private String typ;
    @Column(name = "cecha")
    private String cecha;
    @Column(name = "opis")
    private String opis;

    public test() {
    }

    public test( String nazwa, String typ, String cecha,String opis) {

        this.nazwa = nazwa;
        this.typ = typ;
        this.cecha = cecha;
        this.opis = opis;
    }



    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String gettyp() {
        return typ;
    }

    public void settyp(String typ) {
        this.typ = typ;
    }

    public String getcecha() {
        return cecha;
    }

    public void setcecha(String cecha) {
        this.cecha = cecha;
    }
    public String getopis() {
        return opis;
    }

    public void setopis(String opis) {
        this.opis = opis;
    }
}
