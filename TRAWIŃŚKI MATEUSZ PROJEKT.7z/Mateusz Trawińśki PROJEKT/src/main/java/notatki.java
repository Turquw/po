import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import java.util.Scanner;

public class notatki extends JFrame implements ActionListener {

    JMenuBar menubar;
    JMenu mplik;
    JMenuItem inowy,iotworz,izapisz,iexit;
    JTextArea notatki;
    File plik;
    JFrame sd;


    notatki()
    {
        sd=new JFrame();
        menubar=new JMenuBar();
        mplik=new JMenu("Plik");
        inowy=new JMenuItem("nowy");inowy.addActionListener(this);
        iotworz=new JMenuItem("otworz");iotworz.addActionListener(this);
        izapisz=new JMenuItem("zapisz");izapisz.addActionListener(this);
        iexit=new JMenuItem("exit");iexit.addActionListener(this);
        mplik.add(inowy);mplik.add(iotworz);mplik.add(izapisz);mplik.addSeparator();mplik.add(iexit);
        menubar.add(mplik);
        notatki=new JTextArea();
        JScrollPane scrol =new JScrollPane(notatki);notatki.setFont(new Font("System", Font.BOLD, 15));
        sd.add(scrol);
        sd.setJMenuBar((menubar));
        sd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        sd.setSize(420,420);
        sd.setLocationRelativeTo(null);
        sd.setVisible(true);


    }
    private   void otworz()
    {
        notatki.setText("");
        JFileChooser fc=new JFileChooser();
        if(fc.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)
        {
            plik=fc.getSelectedFile();
            try {
                Scanner scaner=new Scanner(plik);
                while(scaner.hasNext())notatki.append(scaner.nextLine()+"\n");
                scaner.close();
                this.setTitle(fc.getName(plik));
            }
            catch(FileNotFoundException e)
            {e.printStackTrace();}
        }

    }
    private void cos()
    {
        try{
            PrintWriter pw=new PrintWriter(plik);
            Scanner scanner =new Scanner(notatki.getText());
            while(scanner.hasNext()) pw.println(scanner.nextLine());
            scanner.close();pw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
    private void zapisz()
    {
        JFileChooser fc= new JFileChooser();
        fc.setSelectedFile(plik);
        if(fc.showSaveDialog(this)==JFileChooser.APPROVE_OPTION)
        {
            plik=fc.getSelectedFile();
            sd.dispose();
            cos();
        }

    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        Object cel=e.getSource();
        if(cel==iexit) {
            sd.dispose();
            main sdf=new main();
            }
        if(cel==iotworz)otworz();else
        if (cel==inowy){notatki.setText("");this.setTitle("Notatnik");plik=null;}
        if(cel==izapisz){if(plik==null) zapisz();else cos();}
    }
}
