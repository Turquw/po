import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class otwieranko extends JFrame implements ActionListener {
    JComboBox com;
    JFrame frame = new JFrame();
    File plik;
    JTextArea tekst;
    otwieranko(){
        com=new JComboBox();
        JButton back=new JButton("Menu");
        com.setBounds(0,0,120,20);
        back.setBounds(130,0,120,20);
        frame.add(back);
        back.addActionListener(ActionEvent->{main s=new main();frame.dispose();});
        tekst=new JTextArea("");
        tekst.setBounds(0,30,400,390);
        tekst.setFocusable(false);
        frame.add(tekst);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,420);
        frame.setLayout(null);
        frame.setVisible(true);

        File folder = new File("C:\\Users\\mateu\\Documents\\tak");
        File[] listOfFiles = folder.listFiles();
        com.addItem("Nowa Notatka");
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {

                com.addItem(listOfFiles[i].getName());
            }

            com.addActionListener(this);
            frame.add(com);
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==com)
        {
            String cos=com.getSelectedItem().toString();
            if(cos.equals("Nowa Notatka"))
            {
                frame.dispose();
                notatki notatki = new notatki();
            }
            else{
                String tak="C:\\Users\\mateu\\Documents\\tak\\";
                tekst.setText("");
                JFileChooser fc=new JFileChooser(tak+cos);

                plik=new File(tak+cos);
                try {
                    Scanner scaner=new Scanner(plik);
                    while(scaner.hasNext())tekst.append(scaner.nextLine()+"\n");
                    scaner.close();

                }
                catch(FileNotFoundException a)
                {a.printStackTrace();}

            }}



    }
}


