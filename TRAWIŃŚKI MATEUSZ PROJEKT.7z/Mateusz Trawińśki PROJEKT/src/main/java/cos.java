public class cos {
    public static void main(String[] args) {
        main s=new main();
    }
}
