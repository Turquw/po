import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class bohater {
        @Id
        @GeneratedValue

        @Column(name = "imie")
        private String imie;
        @Column(name = "profesja")
        private String profesja;
        @Column(name = "ww")
        private int ww;
        ;
    @Column(name = "us")
    private int us;
    ;
    @Column(name = "K")
    private int K;
    ;
    @Column(name = "Odp")
    private int Odp;
    ;
    @Column(name = "Zr")
    private int Zr;
    ;
    @Column(name = "Int")
    private int Int;
    ;
    @Column(name = "Sw")
    private int Sw;
    ;
    @Column(name = "Ogd")
    private int Ogd;
    ;
    @Column(name = "żyw")
    private int żyw;
    ;
    @Column(name = "A")
    private int A;
    ;@Column(name = "sz")
    private int sz;
    ;
    @Column(name = "Mag")
    private int Mag;
    ;
    @Column(name = "S")
    private int S;
    ;
    @Column(name = "PP")
    private int PP;
    ;
    @Column(name = "Wt")
    private int Wt;
    ;
    @Column(name = "PO")
    private int PO;
    ;
    @Column(name = "BROŃ")
    private String BROŃ;
    ;
    @Column(name = "Pancerz")
    private String Pancerz;
    ;
    @Column(name = "Wyposazenie")
    private String Wyposazenie;
    ;
    @Column(name = "pieniadze")
    private String pieniadze;
    ;
    @Column(name = "Umiejetnosci")
    private String Umiejetnosci;
    ;
    @Column(name = "zdolnosci")
    private String zdolnosci;
    ;




        public bohater() {
        }

        public bohater( String imie, String profesja, int ww,int us,int K,int Odp,int Zr,int Int,int Sw,int Ogd,int żyw,int A,int sz,int Mag,int S,int PP,int Wt,int PO,String BROŃ,String Pancerz,String Wyposazenie,String pieniadze,String Umiejetnosci,String zdolnosci ) {

            this.imie = imie;
            this.profesja = profesja;
            this.ww = ww;
            this.us = us;
            this.K = K;
            this.Odp = Odp;
            this.Zr = Zr;
            this.Int = Int;
            this.Sw = Sw;
            this.Ogd = Ogd;
            this.żyw = żyw;
            this.A = A;
            this.sz = sz;
            this.Mag = Mag;
            this.S = S;
            this.PP = PP;
            this.Wt = Wt;
            this.PO = PO;
            this.BROŃ = BROŃ;
            this.Pancerz = Pancerz;
            this.Wyposazenie = Wyposazenie;
            this.pieniadze = pieniadze;
            this.Umiejetnosci = Umiejetnosci;
            this.zdolnosci = zdolnosci;

        }



        public String getimie() {
            return imie;
        }

        public void setimie(String imie) {
            this.imie = imie;
        }

        public String getprofesja() {
            return profesja;
        }

        public void setprofesja(String profesja) {
            this.profesja = profesja;
        }

        public int getww() {
            return ww;
        }

        public void setww(int cecha) {
            this.ww = cecha;
        }
    public int getus() {
        return us;
    }

    public void setus(int us) {
        this.us = us;
    }
    public int getK() {
        return K;
    }

    public void setK(int K) {
        this.K = K;
    }
    public int getodp() {
        return Odp;
    }

    public void setOdp(int Odp) {
        this.Odp = Odp;
    }
    public int getZr() {
        return Zr;
    }

    public void setZr(int Zr) {
        this.Zr = Zr;
    }
    public int getInt() {
        return Int;
    }

    public void setInt(int Int) {
        this.Int = Int;
    }
    public int getSw() {
        return Sw;
    }

    public void setSw(int Sw) {
        this.Sw = Sw;
    }
    public int getOgd() {
        return Ogd;
    }

    public void setOgd(int Ogd) {
        this.Ogd = Ogd;
    }
    public int getżyw() {
        return żyw;
    }

    public void setżyw(int żyw) {
        this.żyw = żyw;
    }
    public int getA() {
        return A;
    }

    public void setA(int A) {
        this.A = A;
    }
    public int getsz() {
        return sz;
    }

    public void setSz(int sz) {
        this.sz = sz;
    }
    public int getMag() {
        return Mag;
    }

    public void setMag(int Mag) {
        this.Mag = Mag;
    }
    public int getS() {
        return S;
    }

    public void setS(int S) {
        this.S = S;
    }
    public int getPP() {
        return PP;
    }

    public void setPP(int PP) {
        this.PP = PP;
    }
    public int getWt() {
        return Wt;
    }

    public void setWt(int Wt) {
        this.Wt = Wt;
    }
    public int getPO() {
        return PO;
    }

    public void setPO(int PO) {
        this.PO = PO;
    }
    public String getBROŃ() {
        return BROŃ;
    }

    public void setBROŃ(String BROŃ) {
        this.BROŃ = BROŃ;
    }
    public String getPancerz() {
        return Pancerz;
    }

    public void setPancerz(String Pancerz) {
        this.Pancerz = Pancerz;
    }
    public String getWyposazenie() {
        return Wyposazenie;
    }

    public void setWyposazenie(String Wyposazenie) {
        this.Wyposazenie = Wyposazenie;
    }
    public String getpieniadze() {
        return pieniadze;
    }

    public void setpieniadze(String pieniadze) {
        this.pieniadze = pieniadze;
    }
    public String getUmiejetnosci() {
        return Umiejetnosci;
    }

    public void setUmiejetnosci(String Umiejetnosci) {
        this.Umiejetnosci = Umiejetnosci;
    }
    public String getzdolnosci() {
        return zdolnosci;
    }

    public void setzdolnosci(String zdolnosci) {
        this.zdolnosci = zdolnosci;
    }

    }


