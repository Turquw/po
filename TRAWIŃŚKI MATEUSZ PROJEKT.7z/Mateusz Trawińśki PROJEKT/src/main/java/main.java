

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class main implements ActionListener {

    JComboBox com,com2;
    JTextArea tekst,typ,opis,cecha;
    JFrame fs;
    main(){

        JFrame frame = new JFrame();
        JButton kosci =new JButton("Kości");
        JButton zasady =new JButton("Umiejetnosci");
        JButton zdolnosci =new JButton("zdolnosci");
        JButton otwieranko =new JButton("notatki");
        JButton kartypostaci =new JButton("Karty Postaci");
        JButton NPC =new JButton("NPC");
        JLabel tyt=new JLabel("Dziennik Mistrza Gry:Warhamer 2ed");
        tyt.setBounds(0,0,420,30);
        tyt.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,20));
        frame.add(tyt);
        zdolnosci.setFocusable(false);



        kartypostaci.setBounds(0,310,400,40);
        kartypostaci.setFocusable(false);
        kartypostaci.addActionListener(actionEvent->{
            frame.dispose();
            rozwoj tak= new rozwoj();
        });
        frame.add(kartypostaci);
        kosci.setBounds(0,160,400,40);
        kosci.setFocusable(false);
        kosci.addActionListener(actionEvent->{
            frame.dispose();
            kosci tak= new kosci();
        });
        frame.add(kosci);


        otwieranko.setBounds(0,210,400,40);
        otwieranko.setFocusable(false);
        otwieranko.addActionListener(actionEvent ->{frame.dispose();otwieranko dsf =new otwieranko();});
        frame.add(otwieranko);

        zasady.setBounds(0,260,400,40);
        zdolnosci.setBounds(0,360,400,40);
        NPC.setBounds(0,410,400,40);
        NPC.setFocusable(false);
        NPC.addActionListener(ActionEvent->{

            NPCK s=new NPCK();frame.dispose();

        });
        frame.add(NPC);
        zasady.setFocusable(false);

        zasady.addActionListener(actionEvent->
        {

            try {
                frame.dispose();
                fs= new JFrame();
                fs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                fs.setSize(700,552);
                fs.setLayout(null);
                fs.setVisible(true);


                com=new JComboBox();
                JButton back=new JButton("Menu");
                com.setBounds(0,0,120,20);
                back.setBounds(130,0,120,20);
                fs.add(back);
                back.addActionListener(ActionEvent->{main s=new main();fs.dispose();});
                tekst=new JTextArea("");
                typ=new JTextArea("");
                opis=new JTextArea("");
                cecha=new JTextArea("");
                tekst.setBounds(0,20,700,50);
                typ.setBounds(0,70,700,22);
                opis.setBounds(0,142,700,410);
                cecha.setBounds(0,92,700,50);
                tekst.setFocusable(false);
                typ.setFocusable(false);
                opis.setFocusable(false);
                cecha.setFocusable(false);
                fs.add(tekst);
                fs.add(typ);
                fs.add(opis);
                fs.add(cecha);


                DbConnect dbConnect = new DbConnect();
                Connection connection = dbConnect.getConnection();
                String query = "SELECT * FROM zasady";
                ResultSet rs = connection.createStatement().executeQuery(query);

                while (rs.next()){
                    test t = new test();
                    com.addItem(rs.getString("nazwa"));
                    // System.out.print(" nazwa: " + rs.getString("nazwa")+ " typ: " + rs.getString("typ")+ " cecha: " + rs.getString("cecha")+ " opis: " + rs.getString("opis"));
                    System.out.println();

                }
                fs.add(com);
                com.addActionListener( this);


            } catch (SQLException throwables) {
                throwables.printStackTrace();

            }
        });

        zdolnosci.addActionListener(actionEvent->
        {

            try {
                frame.dispose();
                fs= new JFrame();
                fs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                fs.setSize(700,552);
                fs.setLayout(null);
                fs.setVisible(true);


                com2=new JComboBox();
                JButton back=new JButton("Menu");
                com2.setBounds(0,0,120,20);
                back.setBounds(130,0,120,20);
                fs.add(back);
                back.addActionListener(ActionEvent->{main s=new main(); fs.dispose();});
                tekst=new JTextArea("");

                opis=new JTextArea("");

                tekst.setBounds(0,20,700,50);

                opis.setBounds(0,70,700,410);

                tekst.setFocusable(false);

                opis.setFocusable(false);

                fs.add(tekst);

                fs.add(opis);



                DbConnect dbConnect = new DbConnect();
                Connection connection = dbConnect.getConnection();
                String query = "SELECT * FROM zdolnosci";
                ResultSet rs = connection.createStatement().executeQuery(query);

                while (rs.next()){
                    test t = new test();
                    com2.addItem(rs.getString("nazwa"));
                    // System.out.print(" nazwa: " + rs.getString("nazwa")+ " typ: " + rs.getString("typ")+ " cecha: " + rs.getString("cecha")+ " opis: " + rs.getString("opis"));
                    System.out.println();

                }
                fs.add(com2);
                com2.addActionListener( this);


            } catch (SQLException throwables) {
                throwables.printStackTrace();

            }
        });

        frame.add(zasady);
        zasady.setFocusable(false);
        frame.add(zdolnosci);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,552);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource()==com)
        {
            try {
                DbConnect dbConnect = new DbConnect();
                Connection connection = dbConnect.getConnection();
                String query = "SELECT * FROM zasady";
                ResultSet sd = connection.createStatement().executeQuery(query);
                while (sd.next()){
                    test2 t = new test2();
                    String cos=com.getSelectedItem().toString();




                    if(cos.equals(sd.getString("nazwa"))){
                        tekst.setText(sd.getString("nazwa"));
                        tekst.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,40));
                        typ.setText(sd.getString("typ"));
                        typ.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,20));
                        cecha.setText(sd.getString("cecha"));
                        cecha.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,20));
                        opis.setText("opis : "+sd.getString("opis"));
                        opis.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,10));


                    }

            }}
            catch (SQLException throwables) {
                throwables.printStackTrace();

            }
    }
        else if(e.getSource()==com2)
        {
            try {

                DbConnect dbConnect = new DbConnect();
                Connection connection = dbConnect.getConnection();
                String query = "SELECT * FROM zdolnosci";
                ResultSet sd = connection.createStatement().executeQuery(query);
                while (sd.next()){
                    test t = new test();
                    String cos=com2.getSelectedItem().toString();




                    if(cos.equals(sd.getString("nazwa"))){
                        tekst.setText(sd.getString("nazwa"));
                        tekst.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,40));

                        opis.setText("opis : "+sd.getString("opis"));
                        opis.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,20));


                    }

                }}
            catch (SQLException throwables) {
                throwables.printStackTrace();

            }
        }
    }}





