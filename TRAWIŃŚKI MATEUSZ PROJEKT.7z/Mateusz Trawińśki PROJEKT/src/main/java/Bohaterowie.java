import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLOutput;

public class Bohaterowie implements ActionListener {
    JFrame fs;
    JComboBox com;
    JTextArea Imie,profesja,staty,zdolnosci,umiejki,pancez,bron,wyposazenie,ss,zz,um,wyp,pan,br,pien;
    Bohaterowie()  {
         fs = new JFrame();
        fs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fs.setSize(920,440);
        fs.setLayout(null);
        fs.setVisible(true);
        com=new JComboBox();
        JButton back=new JButton("Powrót do menu");
        com.setBounds(0,0,120,20);
        back.setBounds(120,0,120,20);
        back.addActionListener(ActionEvent ->{main s=new main();fs.dispose();});
        fs.add(back);
        Imie=new JTextArea("");
        profesja=new JTextArea("");
        staty=new JTextArea("");
        zdolnosci=new JTextArea("");
        umiejki=new JTextArea("");
        pancez=new JTextArea("");
        bron=new JTextArea("");
        wyposazenie=new JTextArea("");
        ss=new JTextArea("");
        zz=new JTextArea("");
        um=new JTextArea("");
        wyp=new JTextArea("");
        pan=new JTextArea("");
        br=new JTextArea("");
        pien=new JTextArea("");
        Imie.setBounds(0,20,900,50);
        profesja.setBounds(0,70,900,30);
        ss.setBounds(0,100,100,20);
        zz.setBounds(100,100,100,20);
        um.setBounds(200,100,200,20);
        wyp.setBounds(400,100,200,20);
        br.setBounds(600,100,200,20);
        pan.setBounds(800,100,100,20);
        staty.setBounds(0,120,100,320);
        zdolnosci.setBounds(100,120,100,320);
        umiejki.setBounds(200,120,200,320);
        wyposazenie.setBounds(400,120,200,320);
        bron.setBounds(600,120,200,320);
        pancez.setBounds(800,120,100,320);
        Imie.setFocusable(false);
        profesja.setFocusable(false);
        staty.setFocusable(false);
        zdolnosci.setFocusable(false);
        umiejki.setFocusable(false);
        pancez.setFocusable(false);
        bron.setFocusable(false);
        wyposazenie.setFocusable(false);
        ss.setFocusable(false);
        zz.setFocusable(false);
        um.setFocusable(false);
        wyp.setFocusable(false);
        pan.setFocusable(false);
        br.setFocusable(false);
        pien.setFocusable(false);
        fs.add(Imie);
        fs.add(profesja);
        fs.add(staty);
        fs.add(ss);
        fs.add(zz);
        fs.add(um);
        fs.add(umiejki);
        fs.add(zdolnosci);
        fs.add(wyposazenie);
        fs.add(wyp);
        fs.add(pan);
        fs.add(pancez);
        fs.add(br);
        fs.add(bron);
        try{
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getConnection();
        String query = "SELECT * FROM bohater";
        ResultSet rs = connection.createStatement().executeQuery(query);
            com.addItem("Nowa Postac");
            com.addItem("Rozwój");
        while (rs.next()){
            bohater t = new bohater();
            com.addItem(rs.getString("imie"));

        }

        fs.add(com);
        com.addActionListener( this);




        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == com) {

            try {
                DbConnect dbConnect3 = new DbConnect();
                Connection connection3 = dbConnect3.getConnection();
                String query3 = "SELECT * FROM bohater";
                ResultSet sd = connection3.createStatement().executeQuery(query3);
                while (sd.next()){
                    bohater t = new bohater();
                    String cos=com.getSelectedItem().toString();

                    String Staty="WW "+sd.getString("ww")+"\nUS "+sd.getString("us")+"\nK  "+sd.getString("K")+"\nOdp "+sd.getString("Odp")+"\nZr "+sd.getString("Zr")+"\nInt "+sd.getString("Int")+"\nSw "+sd.getString("Sw")+"\nOgd "+sd.getString("Ogd")+"\nżyw "+sd.getString("żyw")+"\nA  "+sd.getString("A")+"\nsz "+sd.getString("sz")+"\nMag "+sd.getString("Mag")+"\nS  "+sd.getString("S")+"\nPP "+sd.getString("PP")+"\nWt "+sd.getString("Wt")+"\nPO "+sd.getString("PO");


                    if(cos.equals(sd.getString("imie"))){
                        Imie.setText(sd.getString("imie"));
                        Imie.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,40));
                        profesja.setText(sd.getString("profesja"));
                        profesja.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,20));
                        ss.setText("Statystyki");
                        zz.setText("zdolnosci");
                        um.setText("umiejetnosci");
                        wyp.setText("Wyposazenie");
                        br.setText("Broń");
                        pan.setText("Pancerz");
                        ss.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,15));
                        zz.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,15));
                        um.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,15));
                        wyp.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,15));
                        br.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,15));
                        pan.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,15));
                        staty.setText(Staty);
                        staty.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,13));
                        zdolnosci.setText(sd.getString("zdolnosci"));
                        zdolnosci.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,13));
                        umiejki.setText(sd.getString("Umiejetnosci"));
                        umiejki.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,13));
                        wyposazenie.setText(sd.getString("Wyposazenie"));
                        wyposazenie.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,13));
                        bron.setText(sd.getString("BROŃ"));
                        bron.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,13));
                        pancez.setText(sd.getString("Pancerz"));
                        pancez.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,13));

                    }
                    else if(cos.equals("Nowa Postac")){
                        fs.dispose();
                        fillpostac s=new fillpostac();}
                    else{fs.dispose();rozwoj s=new rozwoj();}

                }}
            catch (SQLException throwables) {
                throwables.printStackTrace();

            }

        }

    }
    }

