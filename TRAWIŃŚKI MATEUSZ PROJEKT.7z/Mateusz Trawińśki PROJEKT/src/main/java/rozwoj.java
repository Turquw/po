import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static java.lang.Integer.parseInt;

public class rozwoj {
    JFrame fs;
    JLabel imie1,profesja1,ww1,zdolnosci1,umiejki1,pancez1,bron1,wyposazenie1,us1,K1,Odp1,Zr1,Int1,Sw1,Ogd1,zyw1,A1,sz1,Mag1,S1,PP1,Wt1,PO1,pieniadze1;
    JTextArea Imie,profesja,ww,zdolnosci,umiejki,pancez,bron,wyposazenie,us,K,Odp,Zr,Int,Sw,Ogd,zyw,A,sz,Mag,S,PP,Wt,PO,pieniadze;
    JButton zatwierdz,Back;
    JComboBox com;
    rozwoj()
    {
        fs=new JFrame();
        fs = new JFrame();
        fs.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fs.setSize(1000,480);
        fs.setLayout(null);
        fs.setVisible(true);
        com=new JComboBox();
        JButton back=new JButton("Powrót do menu");
        com.setBounds(0,0,120,20);
        com.addItem("Nowa Postac");
        back.setBounds(120,0,120,20);
        back.addActionListener(ActionEvent ->{main s=new main();fs.dispose();});
        fs.add(back);

        imie1=new JLabel("IMIE");imie1.setBounds(0,20,60,20);fs.add(imie1);
        Imie=new JTextArea("");Imie.setBounds(60,20,110,20);fs.add(Imie);
        profesja1=new JLabel("Profesja");profesja1.setBounds(0,41,60,20);fs.add(profesja1);
        profesja=new JTextArea("");profesja.setBounds(60,41,110,20);fs.add(profesja);
        ww1=new JLabel("WW");ww1.setBounds(0,61,60,20);fs.add(ww1);
        ww=new JTextArea("");ww.setBounds(60,61,30,20);fs.add(ww);
        us1=new JLabel("US");us1.setBounds(0,81,60,20);fs.add(us1);
        us=new JTextArea("");us.setBounds(60,81,30,20);fs.add(us);
        K1=new JLabel("K");K1.setBounds(0,101,60,20);fs.add(K1);
        K=new JTextArea("");K.setBounds(60,101,30,20);fs.add(K);
        Odp1=new JLabel("Odp");Odp1.setBounds(0,121,60,20);fs.add(Odp1);
        Odp=new JTextArea("");Odp.setBounds(60,121,30,20);fs.add(Odp);
        Zr1=new JLabel("Zr");Zr1.setBounds(0,141,60,20);fs.add(Zr1);
        Zr=new JTextArea("");Zr.setBounds(60,141,30,20);fs.add(Zr);
        Int1=new JLabel("Int");Int1.setBounds(0,161,60,20);fs.add(Int1);
        Int=new JTextArea("");Int.setBounds(60,161,30,20);fs.add(Int);
        Sw1=new JLabel("Sw");Sw1.setBounds(0,181,60,20);fs.add(Sw1);
        Sw=new JTextArea("");Sw.setBounds(60,181,30,20);fs.add(Sw);
        Ogd1=new JLabel("Ogd");Ogd1.setBounds(0,201,60,20);fs.add(Ogd1);
        Ogd=new JTextArea("");Ogd.setBounds(60,201,30,20);fs.add(Ogd);
        zyw1=new JLabel("żyw");zyw1.setBounds(0,221,60,20);fs.add(zyw1);
        zyw=new JTextArea("");zyw.setBounds(60,221,30,20);fs.add(zyw);
        A1=new JLabel("A");A1.setBounds(0,241,60,20);fs.add(A1);
        A=new JTextArea("");A.setBounds(60,241,30,20);fs.add(A);
        sz1=new JLabel("sz");sz1.setBounds(0,261,60,20);fs.add(sz1);
        sz=new JTextArea("");sz.setBounds(60,261,30,20);fs.add(sz);
        Mag1=new JLabel("Mag");Mag1.setBounds(0,281,60,20);fs.add(Mag1);
        Mag=new JTextArea("");Mag.setBounds(60,281,30,20);fs.add(Mag);
        S1=new JLabel("S");S1.setBounds(0,301,60,20);fs.add(S1);
        S=new JTextArea("");S.setBounds(60,301,30,20);fs.add(S);
        PP1=new JLabel("PP");PP1.setBounds(0,321,60,20);fs.add(PP1);
        PP=new JTextArea("");PP.setBounds(60,321,30,20);fs.add(PP);
        Wt1=new JLabel("Wt");Wt1.setBounds(0,341,60,20);fs.add(Wt1);
        Wt=new JTextArea("");Wt.setBounds(60,341,30,20);fs.add(Wt);
        PO1=new JLabel("PO");PO1.setBounds(0,361,60,20);fs.add(PO1);
        PO=new JTextArea("");PO.setBounds(60,361,30,20);fs.add(PO);
        pieniadze=new JTextArea("");
        zdolnosci1=new JLabel("Zdolnosci");zdolnosci1.setBounds(180,20,60,20);fs.add(zdolnosci1);
        zdolnosci=new JTextArea("");zdolnosci.setBounds(180,40,200,341);fs.add(zdolnosci);
        umiejki1=new JLabel("Umiejetnosci");umiejki1.setBounds(380,20,200,20);fs.add(umiejki1);
        umiejki=new JTextArea("");umiejki.setBounds(380,40,200,341);fs.add(umiejki);
        pancez1=new JLabel("pancez");pancez1.setBounds(580,20,200,20);fs.add(pancez1);
        pancez=new JTextArea("");pancez.setBounds(580,40,200,170);fs.add(pancez);
        bron1=new JLabel("bron");bron1.setBounds(580,211,200,20);fs.add(bron1);
        bron=new JTextArea("");bron.setBounds(580,231,200,150);fs.add(bron);
        wyposazenie1=new JLabel("wyposazenie");wyposazenie1.setBounds(780,20,200,20);fs.add(wyposazenie1);
        wyposazenie=new JTextArea("");wyposazenie.setBounds(780,40,200,341);fs.add(wyposazenie);
        pieniadze1=new JLabel("pieniadze");pieniadze1.setBounds(180,420,60,20);fs.add(pieniadze1);
        pieniadze=new JTextArea("");pieniadze.setBounds(240,420,200,20);fs.add(pieniadze);

        Back=new JButton("Cofnij");Back.setBounds(780,390,200,60);fs.add(Back);Back.addActionListener(actionEvent->{main s =new main();fs.dispose();});
        zatwierdz=new JButton("Zatwierdz");zatwierdz.setBounds(580,390,200,60);fs.add(zatwierdz);
        zatwierdz.addActionListener(actionEvent->{
            try{
                DbConnect dbConnect3 = new DbConnect();
                Connection connection3 = dbConnect3.getConnection();
                PreparedStatement st= dbConnect3.getConnection().prepareStatement("UPDATE bohater SET `profesja`=?,`ww`=?,`us`=?,`K`=?,`Odp`=?,`Zr`=?,`Int`=?,`Sw`=?,`Ogd`=?,`żyw`=?,`A`=?,`sz`=?,`Mag`=?,`S`=?,`PP`=?,`Wt`=?,`PO`=?,`BROŃ`=?,`Pancerz`=?,`Wyposazenie`=?,`pieniadze`=?,`Umiejetnosci`=?,`zdolnosci`=? WHERE imie=?");

                st.setString(1,profesja.getText());


                if(parseInt(ww.getText())<0 || Integer.parseInt(ww.getText())>100||parseInt(us.getText())<0 || Integer.parseInt(us.getText())>100||parseInt(K.getText())<0 || Integer.parseInt(K.getText())>100||parseInt(Odp.getText())<0 || Integer.parseInt(Odp.getText())>100||parseInt(Zr.getText())<0 || Integer.parseInt(Zr.getText())>100||parseInt(Int.getText())<0 || Integer.parseInt(Int.getText())>100||parseInt(Sw.getText())<0 || Integer.parseInt(Sw.getText())>100||parseInt(Ogd.getText())<0 || Integer.parseInt(Ogd.getText())>100||parseInt(zyw.getText())<0 || Integer.parseInt(zyw.getText())>100||parseInt(A.getText())<0 || Integer.parseInt(A.getText())>100||parseInt(sz.getText())<0 || Integer.parseInt(sz.getText())>100||parseInt(Mag.getText())<0 || Integer.parseInt(Mag.getText())>100||parseInt(S.getText())<0 || Integer.parseInt(S.getText())>100||parseInt(PP.getText())<0 || Integer.parseInt(PP.getText())>100||parseInt(Wt.getText())<0 || Integer.parseInt(Wt.getText())>100||parseInt(PO.getText())<0 || Integer.parseInt(PO.getText())>100)
                {
                    JFrame fss;
                    fss = new JFrame();
                    JLabel s=new JLabel("NIE OSZUKUJ ZNASZ ZASADY");s.setBounds(0,0,400,400);
                    fss.add(s);
                    fss.setSize(400,400);
                    fss.setLayout(null);
                    fss.setVisible(true);
                }
                else{
                    st.setInt(2, Integer.parseInt(ww.getText()));
                    st.setInt(3,Integer.parseInt(us.getText()));
                    st.setInt(4,Integer.parseInt(K.getText()));
                    st.setInt(5,Integer.parseInt(Odp.getText()));
                    st.setInt(6,Integer.parseInt(Zr.getText()));
                    st.setInt(7,Integer.parseInt(Int.getText()));
                    st.setInt(8,Integer.parseInt(Sw.getText()));
                    st.setInt(9,Integer.parseInt(Ogd.getText()));
                    st.setInt(10,Integer.parseInt(zyw.getText()));
                    st.setInt(11,Integer.parseInt(A.getText()));
                    st.setInt(12,Integer.parseInt(sz.getText()));
                    st.setInt(13,Integer.parseInt(Mag.getText()));
                    st.setInt(14,Integer.parseInt(S.getText()));
                    st.setInt(15,Integer.parseInt(PP.getText()));
                    st.setInt(16,Integer.parseInt(Wt.getText()));
                    st.setInt(17,Integer.parseInt(PO.getText()));
                    st.setString(18,bron.getText());
                    st.setString(19,pancez.getText());
                    st.setString(20,wyposazenie.getText());
                    st.setString(21,pieniadze.getText());
                    st.setString(22,umiejki.getText());
                    st.setString(23,zdolnosci.getText());
                    st.setString(24,Imie.getText());
                    st.executeUpdate();}
            } catch (SQLException throwables) {
                throwables.printStackTrace();

            }

        });
        DbConnect dbConnect = new DbConnect();
        Connection connection = dbConnect.getConnection();
        String query = "SELECT * FROM bohater";
        try {
            ResultSet rs = connection.createStatement().executeQuery(query);
            while (rs.next()){
                bohater t = new bohater();
                com.addItem(rs.getString("imie"));

            }

            fs.add(com);
            com.addActionListener(ActionEvent->{
                if(com.getSelectedItem().equals("Nowa Postac"))
                {
                    fs.dispose();
                    fillpostac s=new fillpostac();
                }
                else {
                    try {
                        DbConnect dbConnect3 = new DbConnect();
                        Connection connection3 = dbConnect3.getConnection();
                        String query3 = "SELECT * FROM bohater";
                        ResultSet sd = connection3.createStatement().executeQuery(query3);
                        while (sd.next()) {
                            bohater t = new bohater();
                            String cos = com.getSelectedItem().toString();

                            String Staty = "WW " + sd.getString("ww") + "\nUS " + sd.getString("us") + "\nK  " + sd.getString("K") + "\nOdp " + sd.getString("Odp") + "\nZr " + sd.getString("Zr") + "\nInt " + sd.getString("Int") + "\nSw " + sd.getString("Sw") + "\nOgd " + sd.getString("Ogd") + "\nżyw " + sd.getString("żyw") + "\nA  " + sd.getString("A") + "\nsz " + sd.getString("sz") + "\nMag " + sd.getString("Mag") + "\nS  " + sd.getString("S") + "\nPP " + sd.getString("PP") + "\nWt " + sd.getString("Wt") + "\nPO " + sd.getString("PO");


                            if (cos.equals(sd.getString("imie"))) {
                                Imie.setText(sd.getString("imie"));
                                profesja.setText(sd.getString("profesja"));
                                ww.setText(sd.getString("ww"));
                                us.setText(sd.getString("us"));
                                K.setText(sd.getString("K"));
                                Odp.setText(sd.getString("K"));
                                zdolnosci.setText(sd.getString("zdolnosci"));
                                umiejki.setText(sd.getString("Umiejetnosci"));
                                pancez.setText(sd.getString("Pancerz"));
                                bron.setText(sd.getString("BROŃ"));
                                wyposazenie.setText(sd.getString("Wyposazenie"));

                                Zr.setText(sd.getString("Zr"));
                                Int.setText(sd.getString("K"));
                                Sw.setText(sd.getString("Sw"));
                                Ogd.setText(sd.getString("Ogd"));
                                zyw.setText(sd.getString("żyw"));
                                A.setText(sd.getString("A"));
                                sz.setText(sd.getString("sz"));
                                Mag.setText(sd.getString("Mag"));
                                S.setText(sd.getString("S"));
                                PP.setText(sd.getString("PP"));
                                Wt.setText(sd.getString("Wt"));
                                PO.setText(sd.getString("PO"));
                                pieniadze.setText(sd.getString("pieniadze"));

                            } else {
                                fs.dispose();
                                fillpostac s = new fillpostac();
                            }

                        }
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();

                    }


                }});
        } catch (SQLException e) {
            e.printStackTrace();
        }



    }
}