import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class kosci extends JFrame implements ActionListener {
    JFrame frame = new JFrame();
    JButton k6 =new JButton("k6");
    JButton k100 =new JButton("k100");
    JButton k10 =new JButton("k10");
    JButton back =new JButton("wroc do menu");
    JTextField tekst=new JTextField("");

    kosci(){
        k6.setBounds(0,160,400,40);
        k6.setFocusable(false);
        k6.addActionListener(this);
        k100.setBounds(0,260,400,40);
        k100.setFocusable(false);
        k100.addActionListener(this);
        frame.add(k6);
        k10.setBounds(0,210,400,40);
        k10.setFocusable(false);
        k10.addActionListener(this);
        frame.add(k10);
        back.setBounds(0,310,400,40);
        back.setFocusable(false);
        back.addActionListener(this);
        frame.add(back);
        frame.add(k100);
        tekst.setFocusable(false);
        tekst.setBounds(0,0,400,40);
        frame.add(tekst);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,420);
        frame.setLayout(null);
        frame.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==k6) {
            Random rand = new Random();
            int a = rand.nextInt(6)+1;
            tekst.setText(String.valueOf(a));

        }
        if(e.getSource()==k100) {
            Random rand = new Random();
            int a = rand.nextInt(100)+1;
            tekst.setText(String.valueOf(a));

        }
        if(e.getSource()==k10) {
            Random rand = new Random();
            int a = rand.nextInt(10)+1;
            tekst.setText(String.valueOf(a));

        }
        if(e.getSource()==back) {
            frame.dispose();
            main sdf=new main();
        }
    }




}
