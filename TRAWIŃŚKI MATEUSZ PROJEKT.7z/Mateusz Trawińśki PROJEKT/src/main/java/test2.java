import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class test2 {
    @Id
    @GeneratedValue

    @Column(name = "nazwa")
    private String nazwa;

    @Column(name = "opis")
    private String opis;

    public test2() {
    }

    public test2( String nazwa,String opis) {

        this.nazwa = nazwa;
        this.opis = opis;
    }



    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getopis() {
        return opis;
    }

    public void setopis(String opis) {
        this.opis = opis;
    }
}
