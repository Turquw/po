-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 10 Sty 2022, 03:02
-- Wersja serwera: 10.4.21-MariaDB
-- Wersja PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `dzien`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `bohater`
--

CREATE TABLE `bohater` (
  `id` int(11) NOT NULL,
  `imie` varchar(70) NOT NULL,
  `profesja` varchar(70) NOT NULL,
  `ww` int(11) NOT NULL,
  `us` int(11) NOT NULL,
  `K` int(11) NOT NULL,
  `Odp` int(11) NOT NULL,
  `Zr` int(11) NOT NULL,
  `Int` int(11) NOT NULL,
  `Sw` int(11) NOT NULL,
  `Ogd` int(11) NOT NULL,
  `żyw` int(11) NOT NULL,
  `A` int(11) NOT NULL,
  `sz` int(11) NOT NULL,
  `Mag` int(11) NOT NULL,
  `S` int(11) NOT NULL,
  `PP` int(11) NOT NULL,
  `Wt` int(11) NOT NULL,
  `PO` int(11) NOT NULL,
  `BROŃ` varchar(70) NOT NULL,
  `Pancerz` varchar(70) NOT NULL,
  `Wyposazenie` varchar(70) NOT NULL,
  `pieniadze` varchar(70) NOT NULL,
  `Umiejetnosci` varchar(70) NOT NULL,
  `zdolnosci` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `bohater`
--

INSERT INTO `bohater` (`id`, `imie`, `profesja`, `ww`, `us`, `K`, `Odp`, `Zr`, `Int`, `Sw`, `Ogd`, `żyw`, `A`, `sz`, `Mag`, `S`, `PP`, `Wt`, `PO`, `BROŃ`, `Pancerz`, `Wyposazenie`, `pieniadze`, `Umiejetnosci`, `zdolnosci`) VALUES
(1, 'Davpher Reedlade', 'Sługa', 28, 50, 30, 30, 39, 30, 28, 40, 10, 1, 4, 0, 2, 2, 2, 0, 'sztylet s-3\r\nproca 3 zasieg 16/32\r\nkamienie 10', 'brak', 'ubrania dobrej jakosci\r\nmanierka\r\nkrzesiwo\r\nhubka\r\nlatarnia sztormowa\r', '50 złotych koron', 'Gadanina Z\r\nOpieka nad zwierzetami int\r\nPlotkowanie+ ogd\r\nPowożenie K\r', 'Bardzo Silny\nBS: Porca\nCzuły słuch\nEtykieta\nOdpornosc');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `npc`
--

CREATE TABLE `npc` (
  `id` int(11) NOT NULL,
  `imie` varchar(70) NOT NULL,
  `profesja` varchar(70) NOT NULL,
  `ww` int(11) NOT NULL,
  `us` int(11) NOT NULL,
  `K` int(11) NOT NULL,
  `Odp` int(11) NOT NULL,
  `Zr` int(11) NOT NULL,
  `Int` int(11) NOT NULL,
  `Sw` int(11) NOT NULL,
  `Ogd` int(11) NOT NULL,
  `żyw` int(11) NOT NULL,
  `A` int(11) NOT NULL,
  `sz` int(11) NOT NULL,
  `Mag` int(11) NOT NULL,
  `S` int(11) NOT NULL,
  `PP` int(11) NOT NULL,
  `Wt` int(11) NOT NULL,
  `PO` int(11) NOT NULL,
  `BROŃ` varchar(70) NOT NULL,
  `Pancerz` varchar(70) NOT NULL,
  `Wyposazenie` varchar(70) NOT NULL,
  `pieniadze` varchar(70) NOT NULL,
  `Umiejetnosci` varchar(70) NOT NULL,
  `zdolnosci` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `npc`
--

INSERT INTO `npc` (`id`, `imie`, `profesja`, `ww`, `us`, `K`, `Odp`, `Zr`, `Int`, `Sw`, `Ogd`, `żyw`, `A`, `sz`, `Mag`, `S`, `PP`, `Wt`, `PO`, `BROŃ`, `Pancerz`, `Wyposazenie`, `pieniadze`, `Umiejetnosci`, `zdolnosci`) VALUES
(1, 'Arnold lofelfel', 'Inkwizytor', 70, 52, 60, 60, 60, 90, 90, 90, 16, 3, 4, 0, 6, 0, 6, 20, 'miecz ', 'szaty ordo ', 'Pieczęć sigmara', 'ile chce', 'jest inkwizytorem', 'jest inkwizytorem');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zasady`
--

CREATE TABLE `zasady` (
  `id` int(20) NOT NULL,
  `nazwa` varchar(70) NOT NULL,
  `typ` varchar(600) NOT NULL,
  `cecha` varchar(255) NOT NULL,
  `opis` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `zasady`
--

INSERT INTO `zasady` (`id`, `nazwa`, `typ`, `cecha`, `opis`) VALUES
(48, 'Brzuchomówstwo', 'Zaawansowana ', 'Ogłada', 'Bohater potrafi mówic bez otwierania ust.\r\nOsoby uważnie obserwujące Bohatera korzystającego z tej umiejętności mogą wykonać test spotrzegawczości przeciwko testowi brzuchomówstwa BG,\r\nżeby wykryć sztuczkę Bohatera.'),
(49, 'Charakteryzacja', 'Podstawowa', 'Ogłada', 'Wykorzystanie tej umiejętności pozwala Bohaterowi maskować jego prawdziwy wygląd i udawać kogoś innego.\r\nCzęsto Potrzebne są dodatkowe rekwizyty, właściwe ubranie lub peruka.\r\nDzięki tej umiejętności Bohater może przebrać się za przedstawiciela innej rasy,\r\nosobę płci przeciwnej, a nawet kogoś sławnego i znanego w całym kraju,\r\nchoć tego rodzaju charakteryzacja jest znacznie trudniejsza. \r\nPrzeciwko charakteryzacji często wykorzystuje się test spostrzegawczości przeciwnika.'),
(50, 'Czytanie i pisanie', 'Zaawansowana', 'Inteligencja', 'Bohater potrafi czytać i pisać w dowolnym języku, którym umie się posługiwać.\r\nW większości przypadków czytania i pisania nie trzeba testować.\r\nMistrz Gry może jednak zdecydować, że test umiejętności jest potrzebny przy odszyfrowaniu rękopisu spisanego w starożytnym języku,\r\nlub zawierającym niezrozumiałe wyrażenia albo archaiczne słownictwo.'),
(51, 'Czytanie z warg', 'Zaawansowana', 'Inteligencja', 'Dzięki tej umiejętności Bohater może zrozumieć rozmowy prowadzone poza zasięgiem jego słuch lub gdy rozmowa jest zagłuszana przez jakieś odgłosy.\r\nMusi widzieć usta obserwowanej osoby, jak również znać język, w którym prowadzona jest rozmowa.'),
(52, 'Dowodzenia', 'Podstawowa', 'Ogłada', 'Korzystający z tej umiejętności Bohater cieszy się posłuchem u podwładnych.\r\nPo udanym teście umiejętności podwłądni dokładnie wypełaniają jego polecenia.\r\nNieudany test powoduje, że rozkaz zostaje wypełniony błędnie lub też nie zostaje wykonany w ogóle (zależnie od decyzji Mistrza Gry).\r\nDowodzenie nie ma wpływu na zachowanie osób postronnych, umożliwia posłuszeństwo osób podlegających władzy Bohatera.'),
(53, 'Gadanina', 'Zaawansowana', 'Ogłada', 'Bohaterowie posiadający tę umiejętność  mogą próbować zagadać osobę, zasypująć ją potokiem słów.\r\nKorzystający z tej umiejętności Bohater zazwyczaj nie próbuje na nikogo wpływać (do tego służy przekonywanie),\r\nchce po prostu zyskać na czasie. Po udanym teście umiejętności gadanina ofiara ma prawo do testu Siły Woli,\r\nktóry określa czy zorientowała się w tym, co się naprawdę dzieje. Nieudany test oznacza, że \"zagadana\" osoba nic nie robi przez całą rundę,\r\n zastanawiając się, czy ma do czynienia z osobnikiem pijanym czy zwykłym idiotą, a może jedno i drugie.\r\n Gadanina nie przynosi rezultatu, jeśli ofiara bierze udział w walce lub stoi w obliczu ewidentnego zagrożenia życia. \r\nBohater może próbować zagadać kilka osób (jedna osoba za każde 10 punktów jego Ogłady, pod warunkiem, że wszystkie te osoby rozumieją język, któym się posługuje.\r\n'),
(54, 'Hazard', 'Podstawowa', 'Inteligencja', 'Umiejętnosc hazard zwiększa szansę Bohatera za wygraną w grach losowych,\r\ntakich jak karty lub kości. Każda uczestnicząca w grze postać wpłaca stawkę,\r\na potem wszyscy grający jednocześnie wykonują test hazardu. Najniższy wynik rzutu)oczywiście, przy udanym teście)\r\n oznacza wygranie puli.'),
(55, 'Hipnoza', 'zaawansowana', 'siła woli', 'używając hipnozy Bohater może wprowadzić inną osobę w trans.\r\nUwaga hipnotyzowanej osoby musi być przez minutę skupiona na jednej rzeczy (często wykorzystuje się jakąś błyskotkę na łańcuszku lub zapaloną świecę).\r\nPotem należy wykonać test umiejętności.\r\nOsoby próbującego opierać się hipnozie mogą wykonać test Siły Woli.\r\nPo wprowadzeniu osoby w trans, Bohater może jej zadać jedno pytanie za każde 10 punktów swojej Siły Woli. \r\nOsoba udziela odpowiedzi szczerze, zgodnie ze swoją wiedzą. Jeśli głęboko w coś wierzy, to udzieli takiej właśnie informacji. \r\nPo udzieleniu odpowiedzi na ostatnie pytanie osoba wychodzi z transu.'),
(56, 'Jeździectwo', 'podstawowa', 'zręczność', 'Bohater potrafi jeździć konno lub na innych wierzchowcach. \r\nZwykłe jeżdżenie w normalnych warunkach nie wymaga wykonywania testu umiejętności. \r\nJednakże może on być konieczny w przypadku jazdy galopem, wyścigu, podczas jazdy w trudnym terenie, \r\nwskakiwaniu na konia w biegu, itp.'),
(57, 'Język tajemny', 'zaawansowana', 'inteligencja', 'Dzięki tej umiejętności bohater może rzucać zaklęcia.\r\nznajomość języka tajemnego jest konieczna przy używaniu magicznych formuł. \r\nw odróżnieniu od innych języków język Tajemny nie jest używany w codziennych rozmowach, \r\na wyłącznie do manipulowania mocą magiczną. \r\nWszystkie magiczne pergaminy i księgi zapisane są w określonym jężyku tajemnym. \r\nNajczęściej używane to: \r\ndemoniczny\r\nmagiczny (znany wśród uczonych w Imperium pod nazwą Lingua Praestantia) \r\ntajemny elfi.'),
(58, 'Kuglarstwo(różne)', 'zaawansowana', 'Ogłada', 'Kuglarstwo wykorzystywane jest do zabawiania publiczności.\r\npodobnie jak w przypadku nauki i wiedzy nazwa kuglarstwo \r\nokreśla kategorie oddzielnych umiejętności najczęściej spotykanymi rodzajami kóglarstwa są \r\nakrobatyka \r\naktorstwo \r\nbłaznowanie\r\ngawędziarstwo \r\nkomedianctwo\r\nmimika\r\nmuzykalność \r\npołykanie ognia \r\nśpiew \r\ntaniec \r\nwróżenie z dłoni\r\nżonglerka.'),
(59, 'Leczenie', 'zaawansowana', 'Inteligencja', 'Dzięki tej umiejętności Bohater może zapewnić opiekę medyczną rannej osobie\r\nUdany test leczenia przywraca 1k10 punktów Żywotności w przypadku osoby lekko rannej lub 1 punkt Żywotności\r\n w przypadku osoby ciężko rannej.\r\nRanna osoba może być leczona tylko raz podczas sytuacji krytycznej(bitwa, zasadzka, pułapka, upadek, itp.), \r\nktóra spowodowała utratę punktów Żywotności, lub zaraz po niej. Test leczenia można ponowić następnego dnia, \r\njak również każdego kolejnego dnia'),
(60, 'Mocna Głowa', 'podstawowa', 'odporność', 'Ta umiejętność zwiększa odporność bohatera na alkohol. \r\ndoświadczeni Poszukiwacze przygód potrafią sporo wypić i jednocześnie wychodzi względną\r\ntrzeźwość test umiejętności wykonuje się po każdej porcji wypitego alkoholu. '),
(61, 'Nauka (różne)', 'zaawansowana', 'inteligencja', 'Ta umiejętność wykorzystywana jest do zapamiętywania ważniejszych informacji i liczb\r\n jak też (gdy bohater posiada materiały pomocnicze i odpowiednie zasoby) do badań naukowych. \r\nWymaga intensywnej studiów lecz zapewnia znacznie szerszą i jednocześnie bardziej szczegółową znajomość \r\nproblemu niż w przypadku wiedzy ogólnej. nauka nie jest pojedynczą umiejętnością lecz kategorią obejmującą\r\n różne odrębnie traktowanie umiejętności. Każda z nich musi zostać wykupiona oddzielnie. \r\nMusisz wydać 100 PD za każdą wykupioną naukę(w nawiasie wpisujesz nazwe każdej wyuczonej specjalności).\r\n Na przykład umiejętność nauka(teologia) jest odrebną umiejętnością niż nauka(historia). \r\nNajczęściej spotykane dziedziny nauki to \r\nAlchemia\r\nastronomia \r\nDemonologia \r\nfilozofia \r\ngenealogia \r\nheraldyka \r\nhistoria \r\ninżynieria \r\nmagia \r\nmatematyka \r\nnekromancja \r\nprawo \r\nruny \r\nstrategia/taktyka \r\nsztuka\r\nteologia'),
(62, 'Nawigacja', 'zaawansowana', 'inteligencja', 'Umiejętność ta wykorzystywana jest do orientowania się na lądzie i na wodzie. \r\nW zależności od wiedzy i możliwości, \r\nBohater może nawigować według mapy albo gwiazd Posługując się wrodzonym wyczuciem kierunku.\r\n Dzięki tej umiejętności może również ocenić długość podróży, biorąc pod uwagę topografię okolicy, \r\nporę roku i pogodę. W normalnych warunkach utrzymanie stałego kursu wymaga jednego udanego testu \r\numiejętności dziennie w wyjątkowych sytuacjach Mistrz Gry może zażądać dodatkowych testów umiejętności.'),
(63, 'Opieka nad zwierzętami', 'podstawowa', 'inteligencja', 'Umiejętność ta wykorzystywana jest podczas oglądania zwierząt domowych i hodowlanych \r\n(konie, woły, świnie, psy, itd.). Codzienne czynności i karmienie zwierząt nie wymagają testu umiejętności.\r\n Może być jednak potrzebne przy próbie wykrycia objawów choroby lub zastosowanie specjalnych zabiegów \r\n(na przykład zaplatanie grzywy, czesanie, przygotowanie konia do parady wojskowej, itp.).'),
(64, 'Powoożenie', 'podstawowa', 'krzepa', 'Bohater potrafi kierować wozem, powozem, a nawet rydwanem.\r\nPowożenie w normalnych warunkach nie wymaga testu umiejętności.\r\nTest może być potrzebny w przypadku jazdy w trudnym, terenie z dużą prędkością,\r\nlub przy wykonywanie niebezpiecznych manewrów.'),
(65, 'Przekonywanie', 'podstawowa', 'ogłada', 'Ta umiejętność pozwala bohaterowi wpływać na zachowanie innych osób.\r\nMoże przekonywujące kłamać, blefować, a nawet skutecznie żebrać.\r\nPrzekonywanie wykorzystuje się też podczas próby uwodzenia. \r\nW przypadku zastosowania tej umiejętności w celu nakłonienia kogoś do zrobienia czegoś niezwykłego\r\nlub niebezpiecznego. Mistrz Gry może pozwolić nakłanianej postaci na test Siły Woli. \r\nBohater może próbować przekonać kilka osób (jedna osoba za każde 10 punktów jego Ogłady),\r\npod warunkiem że wszystkie te osoby rozumie język, którym posługuje się BG.'),
(66, 'Przeszukanie', 'podstawowa', 'inteligencja', 'Ta umiejętność jest wykorzystywana przy przeszukiwaniu obszaru lub pomieszczenia, \r\nw nadziei znalezienia wskazówek, ukrytych przejść, skarbów lub pułapek. \r\nDokładne przeszukanie pomieszczenia lub niewielkiego obszaru wymaga jednego udanego testu umiejętności.'),
(67, 'Oswajanie', 'zaawansowana', 'ogłada', 'Wykorzystanie tej umiejętności umożliwia oswajanie zwierząt. \r\nZwierzęta domowe i hodowlane zawsze zachowują się przyjaźnie wobec Bohatera, \r\nktóry posiada tę umiejętność. Zwierzęta dzikie lub tresowane (na przykład psy gończe lub bojowe)\r\nmogą dać się oswoić przy udanym teście umiejętności. \r\nMistrz Gry może przydzielić modyfikatory przy próbie oswajania zwierząt wyjątkowo agresywnych \r\nlub wyjątkowo wiernych innej osobie. \r\nUmiejętność oswajanie nie działa na potwory.'),
(68, 'Otwieranie zamków', 'zaawansowana', 'zręczność', 'Bohater potrafi otwierać wszelkiego rodzaju zamki i kłódki. \r\nZazwyczaj do otwarcia zamka wystarczy jeden udany test umiejętności,\r\nale przy próbach otworzenia szczególnie skomplikowanego mechanizmu Mistrz Gry\r\n może zażądać dodatkowych testów umiejętności.'),
(69, 'Plotkowanie', 'podstawowa', 'ogłada', 'Wykorzystanie tej umiejętności pozwala na zbieranie informacji w czasie zwykłej rozmowy.\r\nObejmuje wymianę najświeższych nowin,\r\nplotek o ważnych osobach oraz ogólnych informacji o wydarzeniach w okolicy.'),
(70, 'Rzemiosło', 'zaawansowana', 'różnie', 'Bohater jest fachowcem w jednej z dziedzin rzemiosła.\r\nTa umiejętność obejmuje także te dziedziny, które formalnie nie są określone jako rzemiosło,\r\nale wymagają posiadania wyuczonej wiedzy i odpowiednich narzędzi.\r\nKażda umiejętność rzemiosło dotyczy odrębnej dziedziny. W nawiasie podano cechę,\r\nktóra jest powiązana z daną umiejętnością. Najczęściej spotykanymi dziedzinami rzemiosła są: \r\naptekarstwo(Int)\r\nbednarstwo(S)\r\ngarbarstwo(S), \r\ngotowanie(Int), \r\ngórnictwo(S, \r\nhandel(Ogd), \r\njubilerstwo(Zr), \r\nkaligrafia(Zr), \r\nkamieniarstwo(Zr). \r\nkartografia(Zr). \r\nkowalstwo(S), \r\nkrawiectwo(Zr), \r\nmłynarstwo(S), \r\npiwowarstwo(Int), \r\npłatnerstwo(S), \r\nrusznikarstwo(Zr), \r\nrymarstwo(Zr), \r\nstolarstwo(Zr), \r\nszkutnictwo(Int), \r\nszewstwo(Zr),\r\nsztuka(Zr), \r\nświecarstwo(Zr), \r\nuprawa ziemi(S), \r\nwyrób łuków (Zr), \r\nzielarstwo(int) \r\nzłotnictwo(Zr)'),
(71, 'Sekretne znaki(różne)', 'zaawansowana', 'inteligencja', 'bohater potrafi odczytywać lub zapisywać zaszyfrowane wiadomości.\r\nNa obszarze Imperium stosuje się wiele systemów znaków. \r\nSekretne znaki są zazwyczaj prostymi komunikatami używanymi głównie w celu ostrzeżenia, \r\noznakowania obiektu, wskazania szlaku lub miejsca o szczególnym znaczeniu. \r\nOdczytanie lub zapisane krótkiej, prostej wiadomości nie wymaga testu umiejętności. \r\nW przypadku bardziej skomplikowanych zapisów lub gdy fragmenty znaku są podniszczone lub zatarte, \r\nMistrz Gry może nakazać wykonanie testu umiejętności z odpowiednimi modyfikatorami trudności. \r\nNajczęściej wykorzystywane są znaki: łowców, rycerzy zakonnych, złodziei i zwiadowców.'),
(72, 'Sekretny język(różne)', 'zaawansowana', 'inteligencja', 'znajomość sekretnego języka pozwala na potajemne porozumiewanie się z przedstawicielami\r\ntej samej profesji lub grupy społecznej. Sekretne języki przypominają raczej uproszczonych szyfr,\r\na nie powszechnie używane formy porozumiewania się. Wykorzystując znaki,\r\nmowę ciała i słowa kodowe wplatane w zwykłą wypowiedź, \r\nBohater może przekazać dodatkowe znaczenie wypowiadanych słów lub większą ilość informacji w krótkim czasie.\r\nW normalnych warunkach, gdy wszyscy rozmawiające znają dany sekretny język,\r\ntest umiejętności nie jest potrzebny,\r\naczkolwiek może być wymagany w niesprzyjających warunkach(na przykład na głośnej ulicy lub w czasie bitwy).\r\nNajczęściej używane sekretne języki to: bitewny, łowców i złodziejski.'),
(73, 'Skradanie się', 'podstawowa', 'zręczność', 'Umiejętność ta umożliwia Bohaterowi ciche poruszanie się w prawie każdym terenie.\r\n Skradając się, Bohater może wykonywać najwyżej jedną akcję \"ruch\" w rundzie.\r\n Test skradania się jest często wykonywane w przeciwstawnym teście \r\numiejętności przeciwko spostrzegawczości przeciwnika.'),
(74, 'Splatanie magii', 'zaawansowana', 'Siła Woli', 'Wykorzystanie tej umiejętności ułatwia Bohaterowi kontrolowanie Wiatrów Magii.\r\nKażdy rzucenie zaklęcia wymaga manipulacji Wiatrami Magii, j\r\nednak splatanie magii wykorzystuje się wtedy,\r\ngdy wymagana jest większa kontrola nad czarem lub jego precyzyjne przygotowanie.\r\n '),
(75, 'Spostrzegawczość', 'podstawowa', 'inteligencja', 'Bohater Gracza, który posiada tę umiejętność, dokładniej obserwuje otoczenie, \r\nczęsto zauważając szczegóły przeoczone przez innych. \r\nDzięki temu ma większe szanse na zauważenie pułapki, zapadki lub ukrytego przejścia. \r\nSpostrzegawczość jest używana głównie do ustalania tego co Bohater widzi, \r\nchoć obejmuje także pozostałe zmysły. Może więc być użyto do określenia doznań smakowych, \r\nzapachowych, słuchowych i dotykowych. Spostrzegawczość bywa często stosowana w przeciwstawnych testach umiejętności, \r\nszczególnie przeciwko takim umiejętnościom jak charakteryzacja, spradanie się i ukrywanie się. \r\nUdany test umiejętności pozwala bohaterowi na określenie liczebności, \r\nodległości, wielkości obserwowanego obiektu, itp. Nieudany test może oznaczać uzyskanie niedokładnych informacji.'),
(76, 'Sztuka przetrwania', 'podstawowa', 'inteligencja', 'Umiejętność to może zapewnić przeżycie w dziczy. \r\nObejmuje znajomość technik łowienia ryb, polowania, \r\noprawiania zwierzyny, rozpalania ognia, znajdowania pożywienia, \r\nkonstruowania szałasów, itp.'),
(77, 'Śledzenie', 'zaawansowana', 'zręczność', 'Wykorzystując tę umiejętność bohater może podnosić za kimś,\r\nsamemu pozostając niezauważonym.\r\nTest śledzenia jest często wykonywany w przeciwstawnym teście\r\numiejętności przeciwko spostrzegawczości przeciwnika.'),
(78, 'Targowanie', 'podstawowa', 'ogłada', 'Umiejętność ta umożliwia negocjowanie cen towarów i usług.\r\n W przypadku towarów codziennego użytku wystarczy zwykły test umiejętności. \r\nJeśli Bohater targuje się o cenny przedmiot(na przykłąd próbuje ustalić koszt wyjątkowo cennego rękopisu), \r\nMistrz Gry może zarządzić przeciwstawny test targowania (z ewentualnymi modyfikatorami trudności)'),
(79, 'Torturowanie', 'zaawansowana', 'ogłada', 'Dzięki zastosowaniu rozmaitych działań i środków przymusu bohater \r\npotrafi wydobyć interesujące informacje od osoby niechętnej do współpracy. \r\nUmiejętność obejmuje zarówno psychiczne znęcanie się, jak i fizyczne tortury. \r\nOfiara może opierać się torturom, wykonując test Siły Woli.'),
(80, 'Tresura', 'zaawansowana', 'ogłada', 'Bohater potrafi uczyć zwierzęta wykonywania różnych sztuczek i słuchania prostych poleceń.\r\nZwykle tresurze poddaje się psy, konie i sokoły, \r\nchoć Mistrz Gry może pozwolić na tresowanie bardziej niezwykłych zwierząt. \r\nWyuczenie zwierzęcia zajmuje sporo czasu. Test umiejętności należy wykonywać raz na tydzień tresury. \r\nNauczenie prostej sztuczki wymaga pojedynczego, udanego testu, \r\nśrednio trudna sztuczka wymaga trzech udanych testów umiejętności, \r\nnatomiast bardzo trudna - dziesięciu udanych testów umiejętności.'),
(81, 'Tropienie', 'zaawansowana', 'inteligencja', 'Bohater potrafi wyszukiwać świat zwierząt,\r\na także ludzi innych stworzeń. \r\nPodążanie wyraźnym tropem nie wymaga testu umiejętności i nie spowalnia tempa poruszania się.\r\nTest umiejętności może być jednak potrzebny w trudnych warunkach terenu lub pogody. \r\nOdpowiedni poziom skuteczności może dostarczyć dodatkowych informacji \r\n(o liczebności grupy, odległości od tropionego stworzenia, a nawet jego cechach osobniczych).'),
(82, 'Ukrywanie się', 'podstawowa', 'zręczność', 'Wykorzystanie tej umiejętności umożliwia Bohaterowie ukrywanie się w niemal dowolnym terenie pod warunkiem,\r\n że istnieje realna szansa schowanie się za jakimś obiektem (mur, drzewo, budynek, itp.). \r\nPrzy próbie ukrycia się na otwartej, \r\npustej przestrzeni (na przykład na środku ulicy) test umiejętności automatycznie jest nieudany. \r\nUkrywanie się bywa często wykorzystane przeciwko testowi spostrzegawczości przeciwnika.'),
(83, 'Unik', 'zaawansowana', 'zręczność', 'Wykorzystanie tej umiejętności umożliwia Bohaterowi uniknięcia ataku podczas walki wręcz.\r\n Unik można stosować najwyżej raz na rundę. '),
(84, 'Warzenie trucizn', 'zaawansowana', 'inteligencja', 'Bohater potrafi przyrządzać rozmaite trucizny pochodzenia zwierzęcego lub roślinnego,\r\na także trucizny uzyskiwane alchemiczne.'),
(85, 'Wiedza(różne)', 'zaawansowana', 'inteligencja', 'Umiejętność ta zapewnia wiedzą o zwyczajach, \r\nstrukturze władzy, najważniejszych dostojnikach, \r\nobyczajach ludowych oraz przesądach mieszkańców danej krainy, \r\nczłonków danej grupy społecznej lub przedstawicieli danej rasy. \r\nWiedza nie jest równoznaczna ze studiami naukowymi (to oddaje umiejętność nauka) \r\nlecz zapewnia jedynie podstawowe informacje, jakie Bohater zdobył w czasie podróży po świecie. \r\nPodobnie jak w przypadku umiejętności nauka, \r\nwiedza to szersza kategoria obejmująca różne, \r\noddzielnie zdobywane konkretne umiejętności. \r\nNajczęściej wiedza dotyczy: \r\nBretonii \r\nEstalii, \r\nImperium, \r\nJałowej Krainy, \r\nKisleva, \r\nKsięstw Granicznych, \r\nNorski \r\nelfów, \r\nkrasnoludów, \r\nniziołków  \r\nogrów.'),
(86, 'Wioślarstwo', 'podstawowa', 'krzepa', 'Bohater potrafisz sterować tratwami, barkami i innymi łodziami wiosłowymi. \r\nUtrzymanie kursu w normalnych warunkach i proste manewry nie wymagają testu umiejętności, \r\nMistrz Gry może uznać za stosowne wykonanie testu umiejętności w przypadku kiepskiej pogody, \r\nwysokiej fali, pokonywania progów rzecznych lub omijania mielizn.'),
(87, 'Wspinaczka', 'podstawowa', 'krzepa', 'Twój bohater potrafi wspinać się na drzewa, \r\nmury, skalne ściany i inne pionowe przeszkody. \r\nW normalnych warunkach test umiejętności wykonuje się raz na rundę. \r\nWspinanie się w czasie walki wymaga poświęcenia akcji podwójnej. \r\nUdany też oznacza, że Bohater wspiął się na wysokość równą połowie jego Szybkości (zaokrąglone w górę), \r\nmierzoną w metrach.'),
(88, 'Wycena', 'podstawowa', 'inteligencja', 'Bohater potrafi szacować wartość rzeczy codziennego użytku, \r\njak również przedmiotów wartościowych, \r\ntakich biżuteria, klejnoty i dzieła sztuki. \r\nUdany test umiejętności pozwala odwieźli rynkową wartość przedmiotu. \r\nPonieważ nieudany test umiejętności może spowodować błędne oszacowanie wartości przedmiotu, \r\nMistrz Gry powinien wykonać rzut w tajemnicy i zależne od wyniku poinformować \r\ngracza o ustalonej ten sposób wartości przedmiotu.'),
(89, 'Wykrywanie magii', 'zaawansowana', 'Siła Woli', 'Umiejętność ta umożliwia Bohaterowi wykrywanie subtelnych zawirowań, \r\njakie towarzyszą magicznej aurze. \r\nCzarodzieje opisujące jako szósty, \r\nsiódmy i ósmy zmysły człowieka. \r\nWśród chłopstwa to zjawisko znane jest pod nazwą \"wiedźmi wzrok\". \r\nUdany test umiejętności pozwala określić, czy przedmiot, postać lub obszar pozostaje pod wpływem czaru. \r\nWykorzystując tę umiejętność, czarodziej może ustalić siłę Wiatrów Magii w najbliższej okolicy. Dodatkowe informacje na ten temat znajdziesz w rozdziale VII: Magia\r\n'),
(90, 'Zastawianie pułapek', 'zaawansowana', 'zręczność', 'Bohater potrafi konstruować różnego rodzaju pułapki na zwierzęta. \r\nW Imperium używa się pułapek unieruchamiających, jak też uśmiercających złapane zwierzę. \r\nZa każdą złożoną pułapkę wykonuje się jeden test umiejętności na dzień. Udany test oznacza, \r\nże w pułapkę złapało się zwierze.'),
(91, 'Zastraszanie', 'podstawowa', 'krzepa', 'Dzięki tej umiejętności Bohater może zastraszać lub zmuszać do uległości inne osoby. \r\nOfiary, które nie chcą ugiąć się przed groźbami, mogą wykonać test Siły Woli. \r\nReakcja postaci zależy całkowicie od decyzji Mistrza Gry, \r\nktóry bierze pod uwagę jej osobowość oraz wynik testu zastraszania.\r\nW niektórych sytuacjach (szantaż, itp) Mistrz gry może uznać, \r\nże bardziej odpowiednią cechą do testu zastraszania może być Ogłada.'),
(92, 'Znajomość języka', 'zaawansowana', 'inteligencja.', 'Ta umiejętność umożliwia Bohaterowi porozumiewanie się w obcym języku.\r\nWiększość języku Starego Świata wywodzi się ze wspólnego starożytnego narzecza,\r\nchoć w ciągu wielu wieków różnice między poszczególnymi dialektami doprowadziły\r\ndo powstawania odrębnych języków. W normalnych warunkach\r\ngdy wszyscy rozmawiający znają dany język, test umiejętności nie jest potrzebny\r\nTest umiejętności może być potrzebny w przypadku prób naśladowania regionalnych akcentów\r\nlub gdy Bohater Gracza próbuje przekonać słuchających, że język obcy jest ojczystym jego językiem.\r\nNajczęściej używanymi językami są\r\nbretnośki(Bretonia)\r\neltharin(elfi) \r\nestalijski(Estalia, \r\nkhazalid(krasnoludzki), \r\nkislevski(kislev), \r\nnorski(Norska), \r\ntileański(Tilea),  \r\nReikspiel czyli staroświatowy (Imperium)  \r\njęzyk niziołków\r\nUczeni posługują się także językiem klasycznym, choć obecnie występuje on głównie w formie pisanej.\r\nMniej cywilizowane rasy posługują się językiem goblińskim (orki, gobliny i hobgobliny)\r\nnarzeczem grumbarth(ogry) oraz mroczną mową (zwierzoludzie i inne istoty Chaosu).'),
(93, 'Zwinne palce', 'zaawansowana', 'zręczność', 'Dzięki tej użytecznej umiejętności Bohater potrafi ukryć w dłoni małe przedmioty\r\n lub wykonywać sztuczki z kartami i monetami. \r\nZwinne palce przydają się również przy ukradkowym sięganiu do cudzych sakiewek. \r\nTest zwinnych palców jest często wykonywany w przeciwstawnym teście umiejętności przeciwko \r\nspostrzegawczości przeciwnika.'),
(94, 'Żeglarstwo', 'zaawansowanie', 'zręczność', 'Dzięki tej umiejętności Bohater potrafi sterować statkami żaglowymi.\r\nDodatkowo bohater dysponuje wiedzą o budowie okrętów,\r\nróżnych rodzajach żagli, a także umiejętnością przewidywania pogody na morzu.\r\nŻeglowanie po spokojnych wodach nie wymaga testu umiejętności. \r\nTrudne warunki pogodowe, wysokie fale lub wykonywanie manewrów w czasie bitwy \r\nmogą wymagać testu umiejętności o odpowiednim stopniu trudności. ');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zdolnosci`
--

CREATE TABLE `zdolnosci` (
  `id` int(20) NOT NULL,
  `nazwa` varchar(70) NOT NULL,
  `opis` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `zdolnosci`
--

INSERT INTO `zdolnosci` (`id`, `nazwa`, `opis`) VALUES
(1, 'Artylerzysta', 'Bohater został świetnie wyszkolony w obsłudze broni palnej.\r\nDzięki tej zdolności może przeładować broń palną w czasie krótszym o akcję.\r\n Jeśli Bohater posiada również zdolność błyskawiczne przeładowanie,\r\n może korzystać naraz z obu zdolności (skracając czas przeładowania broni palnej o akcję podwójną)'),
(2, 'Bardzo Silny', 'Bohater obdarzony jest wyjątkową siła.\r\n Otrzymuje +5 do Krzepy, \r\ndodawane do początkowej wartości cechy.'),
(3, 'Bardzo Szybki', 'Bohater potrafi poruszać się znacznie szybciej niż inni. \r\nOtrzymuje +1 do Szybkości, dodawane do początkowej wartości cechy.'),
(4, 'Bijatyka', 'Bohater nauczył się walczyć w karczemnych burdach i miejskich rozróbach. \r\nOtrzymuje modyfikator +10 do Walki Wręcz podczas ataku bez broni. \r\nDodatkowo otrzymuje modyfikator +1 do obrażeń zadawanych podczas takiego ataku.'),
(5, 'Błyskawiczne przeładowanie', 'Bohater jest doświadczonym strzelcem. \r\nDzięki tej zdolności może przeładować broń strzelecką w czasie krótszym o akcję. \r\nBohater używający błyskawicznego przeładowania może napiąć kuszę w czasie jednej akcji zwykłej, \r\npodczas  gdy normalnie wymaga to akcji podwójnej. Jeśli przeładowanie broni normalnie zajmuje akcję, \r\nkorzystając z tej zdolności można to wykonać w ramach akcji natychmiastowej. \r\nDzięki temu Bohater może przeładować taką broń praktycznie w mgnieniu oka, co pozwala na wykonanie \r\n\"ataku wielokrotnego\" z broni strzeleckiej. '),
(6, 'Błyskawiczny blok', 'Bohater, który wykonuje \"atak wielokrotny\"\r\nmoże poświęcić jeden z ataków, otrzymując w zamian możliwość sparowania ataku przeciwnika. \r\nNa przykład Bohater mający 3 Ataki i deklarujący atak wielokrotny, \r\nmógłby wykonać dwa ataki i raz sparować atak przeciwnika. \r\nBohater nadal może parować najwyżej jeden atak na rundę.'),
(7, 'Błyskotliwość', 'Bohater obdarzony jest wyjątkową inteligencją. \r\nOtrzymuje +5 do Inteligencji, dodawane do początkowej wartości cechy.'),
(8, 'Brawura', 'Obdarzony tą zdolnością Bohater wykazuje się wyjątkową śmiałością i ruchliwością w walce. \r\nMoże wykonać akcję \"skok\" poświęcając na to akcję zwykłą (zamiast akcji podwójnej. \r\nZdolność zwiększa też maksymalny zasięg wszystkich skoków o 1 metr.'),
(9, 'Broń naturalna', 'Postać dysponuje ostrymi kłami lub pazurami, \r\nktórych z powodzeniem może używać w walce. \r\nW czsaie walki bez broni jest traktowana, jak gdyby używała broni jednoręcznej. \r\nBroń naturalna nie pozwala na parowanie ciosów. W przypadku broni naturalnej nie można stosować rozbrajania.'),
(10, 'Broń specjalna(różne)', 'Bohater potrafi władać bronią, która wymaga specjalistycznego treningu. \r\nKażda zdolność broń specjalna jest odrębną zdolnością. \r\nNa przykład broń specjalna(dwuręczna) różni się od zdolności broń specjalna(rzucana) \r\nKażda zdolność musi zostać wykupiona oddzielnie. \r\nNajczęściej spotykanymi rodzajami broni specjalnych są:\r\n dwuręczna, \r\nkawaleryjska, \r\nmechaniczna, \r\npalna, \r\nparująca, \r\nrzucana, \r\nszermiercza, \r\nunieruchamiająca \r\nkorbacze, \r\nkusze, \r\nłuki \r\nproce. '),
(11, 'Bystry wzrok', 'Bohater obdarzony jest doskonałym wzrokiem. \r\nOtrzymuje modyfikator +10 do testów spostrzegawczości podczas rozglądania się oraz do testów czytania z warg.'),
(12, 'Charyzmatyczny', 'Bohater obdarzony jest zniewalającym urokiem osobistym. \r\nOtrzymuje +5 do Ogłady, dodawane do początkowej wartości cechy.'),
(13, 'Chirurgia', 'Bohater poznał tajniki najnowszej wiedzy medycznej. \r\nOtrzymuje modyfikator +10 do testów leczenia. \r\nW przypadku leczenia ciężko rannego pacjenta udany test przywraca 2 punkty Żywotności zamiast, \r\njak normalnie, tylko1. Jeśli w wyniku trafienia krytycznego istnieje ryzyko utraty kończyny, \r\npacjent leczony przez chirurga otrzymuje modyfikator +20 do Odporności podczas testów związanych z ryzykiem \r\nutraty kończyny. '),
(14, 'Chodu!', 'Bohater poznał sekret Czarnej Magii Dhar i potrafi jej używać do wspomożenia siły swoich zaklęć.\r\nKorzystanie z czarnoksięstwa umożliwia zdobycie większej mocy, ale jest także bardziej ryzykowne.\r\nZa każdym razem, gdy Bohater rzuca czar, może wykorzystać energię Dhar do jego wzmocnienia.\r\nWykonując rzut na poziom mocy czaru, możesz rzucić dodatkową kostką k10 i zignorować najmniejszy\r\n z uzyskanych wyników, któy jednak liczy się podczas sprawdzaniu Przekleństwa Tzeentcha. \r\nNa przykład czarodziej z Magią 2, który rzuca zaklęcie z wykorzystaniem czarnoksięstwa, rzuca 3k10 i \r\nwybiera dwa najwyższe wyniki. Wszystkie trzy kostki są używane do sprawdzania Przekleństwa Tzeentcha. \r\nGdyby na kostkach wypadło 6, 6 i 6, poziom mocy czaru wyniósłby 12(6+6), \r\njednak czar wywołałby Poważną Manifestację Chaosu. Znajomość czarnoksięstwa jest wymagana przy rzucaniu\r\n czarów z magii czarnoksięskiej. '),
(15, 'Człowiek-guma', 'Bohater potrafi wyginać swoje ciało w sposób nieosiągalny dla zwykłych osób.\r\n Otrzymuje modfikator +10 do testów kuglarstwa(akrobatyka) oraz modyfikator +20 do \r\nZręczności podczas testów wyzwalania się z więzów. przeciskania przez szczeliny itp.'),
(16, 'Czuły słuch', 'Bohater obdarzony jest wyjątkowo czułym słuchem. \r\nOtrzymuje modyfikator +20 do testów spostrzegawczości podczas nasłuchiwania.'),
(17, 'Dotyk mocy', 'Niektóre czary używane w walce wymagają dotknięcia przeciwnika. Bohater, \r\nktóry posiada zdolność dotyk mocy, otrzymuje modyfikator +20 do Walki Wręcz \r\nprzy testach związanych z rzucaniem czarów dotykowych.');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `bohater`
--
ALTER TABLE `bohater`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `npc`
--
ALTER TABLE `npc`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `zasady`
--
ALTER TABLE `zasady`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `bohater`
--
ALTER TABLE `bohater`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `npc`
--
ALTER TABLE `npc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `zasady`
--
ALTER TABLE `zasady`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
